import flet as ft
from datetime import datetime, timedelta
import asyncio

def main(page: ft.Page):
    # Initialize UI elements
    countdown_text = ft.Text("", size=32, text_align="center")
    breakdown_text = ft.Text("", size=28, text_align="center")
    progress_text = ft.Text("", size=22, text_align="center")
    progress_bar = ft.ProgressBar(value=0, width=450, height=20, border_radius=4)

    # Update function
    async def update_countdown():
        while True:
            now = datetime.now()
            end_of_year = datetime(now.year, 12, 31, 23, 59, 59)
            remaining_time = end_of_year - now
            total_year_time = timedelta(days=365 if now.year % 4 else 366)

            # Line 1: Total time left
            countdown_text.value = f"Time left in {now.year}"

            # Line 2: Breakdown of remaining time
            months_left = remaining_time.days // 30
            days_left = remaining_time.days % 30
            hours_left, remainder = divmod(remaining_time.seconds, 3600)
            minutes_left = remainder // 60
            breakdown_text.value = (
                f"{months_left} months, {days_left} days, "
                f"{hours_left} hours, {minutes_left} minutes"
            )

            # Line 3: Progress of the year
            elapsed_time = total_year_time - remaining_time
            progress_percentage = (elapsed_time / total_year_time) * 100
            progress_text.value = f"{progress_percentage:.2f}% of the year has passed"

            # Update progress bar
            progress_bar.value = progress_percentage / 100

            # Update UI
            page.update()

            # Wait for 60 seconds
            await asyncio.sleep(60)

    # Start the update loop with an event loop
    def start_update():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(update_countdown())

    # Add elements to a centered Column
    page.add(
        ft.Container(
            content=ft.Column(
                [
                    countdown_text,
                    breakdown_text,
                    progress_text,
                    progress_bar,  # Add progress bar to the UI
                ],
                alignment="center",
                horizontal_alignment="center",
            ),
            alignment=ft.alignment.center,
            expand=True,
        )
    )
    # Run the background task in a thread
    import threading
    threading.Thread(target=start_update, daemon=True).start()

# Run the app
ft.app(target=main)
