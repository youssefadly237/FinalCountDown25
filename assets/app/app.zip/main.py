import flet as ft
from datetime import datetime, timedelta
import asyncio

def main(page: ft.Page):
    Exams = {
        "Religious Education"          :[datetime(2025, 2, 15, 9     ), 1.5],
        "National Education"           :[datetime(2025, 6, 15, 11    ), 1.5],
        "URT Arabic"                   :[datetime(2025, 6, 19, 9     ), 2  ],
        "TOC Arabic"                   :[datetime(2025, 6, 19, 11, 30), 1  ],
        "URT English"                  :[datetime(2025, 6, 22, 9,    ), 1.5],
        "TOC Chemistry"                :[datetime(2025, 6, 24, 9     ), 2  ],
        "TOC English"                  :[datetime(2025, 6, 26, 9     ), 3  ],
        "URT SFL"                      :[datetime(2025, 6, 29, 9     ), 2  ],
        "TOC SFL"                      :[datetime(2025, 6, 29, 11, 30), 1  ],
        "TOC Physics"                  :[datetime(2025, 7, 1,  9,    ), 2  ],
        "URT Chem & Phy"               :[datetime(2025, 7, 3,  9,    ), 1.5],
        "TOC Geo / Mech"               :[datetime(2025, 7, 6,  9     ), 2  ],
        "URT Bio & Geo / Math & Mech"  :[datetime(2025, 7, 8,  9     ), 1.5],
        "TOC Bio / Math"               :[datetime(2025, 7, 10, 9     ), 2  ]
    }
    mainColor = "indigo400"

    countdown_text = ft.Text("", size=32, text_align="center")
    breakdown_text = ft.Text("", size=28, text_align="center")
    progress_text = ft.Text("", size=14, text_align="center")
    progress_bar = ft.ProgressBar(value=0, width=450, height=20, border_radius=4, color=mainColor)

    exam_texts = {}

    def create_exam_container(title, exam_date):
        """Creates a container with exam details."""
        remaining_text = ft.Text("", size=14, text_align="center")
        exam_texts[title] = remaining_text  # Store reference

        return ft.Container(
            content=ft.Column([
                ft.Text(title, size=18, weight="bold", text_align="center"),
                remaining_text
            ], alignment="center", horizontal_alignment="center"),
            width=350,
            height=100,
            padding=10,
            alignment=ft.alignment.center,
            bgcolor=mainColor,
            border_radius=10
        )

    # Generate rows of 3 exams per row
    rows = []
    exams_list = list(Exams.items())

    for i in range(0, len(exams_list), 3):
        row = ft.Row(
            [create_exam_container(title, date) for title, (date, _) in exams_list[i:i+3]],
            alignment=ft.MainAxisAlignment.CENTER
        )
        rows.append(row)

    async def update_countdown():
        while True:
            now = datetime.now()
            examStart = Exams["Religious Education"][0]
            examEnd = Exams["TOC Bio / Math"][0] + timedelta(hours=Exams["TOC Bio / Math"][1])

            # Update main countdown
            if now < examStart:
                remaining_time = examStart - now
                countdown_text.value = "Time left for the finals"
            else:
                remaining_time = examEnd - now
                countdown_text.value = "جاري تحرير العبيد..."
                countdown_text.rtl = True

            # Breakdown of remaining time
            months_left = remaining_time.days // 30
            days_left = remaining_time.days % 30
            hours_left, remainder = divmod(remaining_time.seconds, 3600)
            minutes_left = remainder // 60
            breakdown_text.value = f"{months_left} months, {days_left} days, {hours_left} hours, {minutes_left} minutes"

            # Update exam countdowns
            for title, (exam_date, _) in Exams.items():
                remaining_time = exam_date - now
                if remaining_time < timedelta(0):
                    exam_texts[title].value = "Done!"
                else:
                    days_left = remaining_time.days
                    hours_left = remaining_time.seconds // 3600
                    minutes_left = (remaining_time.seconds % 3600) // 60
                    exam_texts[title].value = f"{days_left}d {hours_left}h {minutes_left}m"

            # Update progress bar
            if now >= examStart:
                totalExamTime = examEnd - examStart
                elapsed_time = totalExamTime - remaining_time
                progress_percentage = (elapsed_time / totalExamTime) * 100
                progress_bar.value = progress_percentage / 100
                progress_bar.visible = True
            else:
                progress_bar.visible = False

            page.update()
            await asyncio.sleep(60)

    # Start async update task on page load
    page.run_task(update_countdown)

    def start_update():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(update_countdown())

    page.add(
        ft.Container(
            content=ft.Column(
                [
                    countdown_text,
                    breakdown_text,
                    progress_text,
                    progress_bar,
                    progress_text,
                    ft.Column(rows, alignment="center", horizontal_alignment="center")
                ],
                alignment="center",
                horizontal_alignment="center",
            ),
            alignment=ft.alignment.center,
            expand=True,
        ),
        ft.Container(
            content=ft.TextButton(
                "by Adly",
                url="https://youssefadly237.github.io/",  # Replace with your GitHub profile or repo link
                style=ft.ButtonStyle(padding=10, shape=ft.RoundedRectangleBorder(radius=5)),
                ),
            alignment=ft.alignment.center,
        )
    )  

    import threading
    threading.Thread(target=start_update, daemon=True).start()

ft.app(target=main)
